from django.apps import AppConfig


class DemoappConfig(AppConfig):
    name = 'DEMOAPP'
